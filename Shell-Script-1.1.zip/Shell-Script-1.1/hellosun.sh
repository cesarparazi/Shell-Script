#!/bin/bash
clear;
echo "Hello World";
echo "Hello Sunshine"
exit;
