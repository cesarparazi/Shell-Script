#!/bin/bash
clear;
echo "Hello World";
echo "Hello Moon"
exit;
