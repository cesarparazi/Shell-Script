#!/bin/bash
clear;
echo "Hello World";
exit;
